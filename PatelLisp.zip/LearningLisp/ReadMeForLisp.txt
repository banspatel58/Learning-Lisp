README File for LISP

To compile and run program on tesla use:

clisp filename.lsp